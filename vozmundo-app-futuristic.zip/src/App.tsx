import { useState, useRef, useEffect } from 'react'
import './App.css'

function App() {
  const [inputText, setInputText] = useState('')
  const [sourceLanguage, setSourceLanguage] = useState('auto')
  const [targetLanguage, setTargetLanguage] = useState('pt-BR')
  const [isTranslating, setIsTranslating] = useState(false)
  const [translatedText, setTranslatedText] = useState('')
  const [isPlaying, setIsPlaying] = useState(false)
  const [isDarkTheme, setIsDarkTheme] = useState(true)
  const [voiceType, setVoiceType] = useState('default')
  const [speechRate, setSpeechRate] = useState(1)
  const [pdfPreview, setPdfPreview] = useState('')
  const [isScanning, setIsScanning] = useState(false)
  
  // Referência para controlar a síntese de voz
  const speechSynthesisRef = useRef<SpeechSynthesisUtterance | null>(null)
  
  // Lista de idiomas suportados
  const languages = [
    { code: 'auto', name: 'Detectar idioma' },
    { code: 'pt-BR', name: 'Português (Brasil)' },
    { code: 'en-US', name: 'Inglês (EUA)' },
    { code: 'es-ES', name: 'Espanhol' },
    { code: 'fr-FR', name: 'Francês' },
    { code: 'de-DE', name: 'Alemão' },
    { code: 'it-IT', name: 'Italiano' },
    { code: 'ja-JP', name: 'Japonês' },
    { code: 'zh-CN', name: 'Chinês (Simplificado)' },
    { code: 'ru-RU', name: 'Russo' },
  ]

  // Efeito para aplicar o tema
  useEffect(() => {
    document.documentElement.setAttribute('data-theme', isDarkTheme ? 'dark' : 'light');
  }, [isDarkTheme]);

  // Função simulada de tradução (será substituída pela integração real com API)
  const handleTranslate = () => {
    if (!inputText.trim()) return
    
    setIsTranslating(true)
    setIsScanning(true)
    
    // Simulando uma tradução com delay para demonstração
    setTimeout(() => {
      setTranslatedText(`Texto traduzido: ${inputText}`)
      setIsTranslating(false)
      setIsScanning(false)
    }, 1500)
  }

  // Função para lidar com upload de PDF
  const handlePdfUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      // Verificar se é um PDF
      if (file.type !== 'application/pdf') {
        alert('Por favor, selecione um arquivo PDF válido.');
        return;
      }
      
      // Criar uma URL para o arquivo
      const fileUrl = URL.createObjectURL(file);
      setPdfPreview(fileUrl);
      
      // Simulando extração de texto do PDF
      setIsScanning(true);
      setTimeout(() => {
        setInputText(`[Texto extraído do PDF: ${file.name}]`);
        setIsScanning(false);
      }, 1000);
    }
  }

  // Função para reproduzir o texto como áudio
  const handlePlayAudio = () => {
    if (!translatedText) return
    
    // Se já estiver tocando, não faz nada
    if (isPlaying) return
    
    // Usando a API Web Speech para síntese de voz
    const utterance = new SpeechSynthesisUtterance(translatedText)
    utterance.lang = targetLanguage
    utterance.rate = speechRate
    
    // Configurando eventos para controlar o estado de reprodução
    utterance.onstart = () => setIsPlaying(true)
    utterance.onend = () => setIsPlaying(false)
    utterance.onpause = () => setIsPlaying(false)
    utterance.onresume = () => setIsPlaying(true)
    
    // Armazenando a referência para controle posterior
    speechSynthesisRef.current = utterance
    
    // Iniciando a reprodução
    window.speechSynthesis.speak(utterance)
    setIsPlaying(true)
  }
  
  // Função para pausar a reprodução do áudio
  const handlePauseAudio = () => {
    if (isPlaying && window.speechSynthesis) {
      window.speechSynthesis.pause()
      setIsPlaying(false)
    }
  }
  
  // Função para retomar a reprodução do áudio
  const handleResumeAudio = () => {
    if (!isPlaying && window.speechSynthesis) {
      window.speechSynthesis.resume()
      setIsPlaying(true)
    }
  }
  
  // Função para alternar entre pausar e retomar
  const handleTogglePlayPause = () => {
    if (isPlaying) {
      handlePauseAudio()
    } else {
      // Se não estiver tocando e não tiver uma utterance, inicia uma nova
      if (!speechSynthesisRef.current) {
        handlePlayAudio()
      } else {
        handleResumeAudio()
      }
    }
  }

  // Função para alternar o tema
  const toggleTheme = () => {
    setIsDarkTheme(!isDarkTheme);
  }

  // Ícones SVG
  const icons = {
    pdf: (
      <svg className="icon" viewBox="0 0 24 24">
        <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path>
        <polyline points="14 2 14 8 20 8"></polyline>
        <line x1="16" y1="13" x2="8" y2="13"></line>
        <line x1="16" y1="17" x2="8" y2="17"></line>
        <polyline points="10 9 9 9 8 9"></polyline>
      </svg>
    ),
    play: (
      <svg className="icon" viewBox="0 0 24 24">
        <polygon points="5 3 19 12 5 21 5 3"></polygon>
      </svg>
    ),
    pause: (
      <svg className="icon" viewBox="0 0 24 24">
        <rect x="6" y="4" width="4" height="16"></rect>
        <rect x="14" y="4" width="4" height="16"></rect>
      </svg>
    ),
    sun: (
      <svg className="icon" viewBox="0 0 24 24">
        <circle cx="12" cy="12" r="5"></circle>
        <line x1="12" y1="1" x2="12" y2="3"></line>
        <line x1="12" y1="21" x2="12" y2="23"></line>
        <line x1="4.22" y1="4.22" x2="5.64" y2="5.64"></line>
        <line x1="18.36" y1="18.36" x2="19.78" y2="19.78"></line>
        <line x1="1" y1="12" x2="3" y2="12"></line>
        <line x1="21" y1="12" x2="23" y2="12"></line>
        <line x1="4.22" y1="19.78" x2="5.64" y2="18.36"></line>
        <line x1="18.36" y1="5.64" x2="19.78" y2="4.22"></line>
      </svg>
    ),
    moon: (
      <svg className="icon" viewBox="0 0 24 24">
        <path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"></path>
      </svg>
    ),
    translate: (
      <svg className="icon" viewBox="0 0 24 24">
        <path d="M12.87 15.07l-2.54-2.51.03-.03A17.52 17.52 0 0 0 14.07 6H17V4h-7V2H8v2H1v2h11.17C11.5 7.92 10.44 9.75 9 11.35 8.07 10.32 7.3 9.19 6.69 8h-2c.73 1.63 1.73 3.17 2.98 4.56l-5.09 5.02L4 19l5-5 3.11 3.11.76-2.04zM18.5 10h-2L12 22h2l1.12-3h4.75L21 22h2l-4.5-12zm-2.62 7l1.62-4.33L19.12 17h-3.24z"></path>
      </svg>
    )
  };

  return (
    <div className="app-container">
      <header className="app-header">
        <h1>VozMundo</h1>
        <p>Traduza textos e ouça em diversos idiomas</p>
      </header>

      <main className="app-content">
        <section className="input-section">
          <div className="language-selector">
            <label htmlFor="source-language">Idioma de origem:</label>
            <select 
              id="source-language"
              value={sourceLanguage}
              onChange={(e) => setSourceLanguage(e.target.value)}
            >
              {languages.map((lang) => (
                <option key={lang.code} value={lang.code}>
                  {lang.name}
                </option>
              ))}
            </select>
          </div>

          <div className="text-input-container">
            <textarea
              className={`text-input ${isScanning ? 'scanning' : ''}`}
              placeholder="Digite ou cole o texto aqui..."
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              aria-label="Texto para tradução"
            />
            
            {pdfPreview && (
              <div className="pdf-preview">
                <embed src={pdfPreview} type="application/pdf" width="100%" height="140px" />
              </div>
            )}
            
            <div className="input-actions">
              <button 
                className="action-button upload-button"
                onClick={() => document.getElementById('pdf-upload')?.click()}
                aria-label="Carregar PDF"
              >
                {icons.pdf} Carregar PDF
              </button>
              <input
                type="file"
                id="pdf-upload"
                accept="application/pdf"
                style={{ display: 'none' }}
                onChange={handlePdfUpload}
              />
            </div>
          </div>
        </section>

        <section className="translation-controls">
          <div className="language-selector">
            <label htmlFor="target-language">Traduzir para:</label>
            <select 
              id="target-language"
              value={targetLanguage}
              onChange={(e) => setTargetLanguage(e.target.value)}
            >
              {languages.filter(lang => lang.code !== 'auto').map((lang) => (
                <option key={lang.code} value={lang.code}>
                  {lang.name}
                </option>
              ))}
            </select>
          </div>

          <button 
            className="translate-button"
            onClick={handleTranslate}
            disabled={isTranslating || !inputText.trim()}
            aria-label="Traduzir texto"
          >
            {isTranslating ? 'Traduzindo...' : (
              <>
                {icons.translate} Traduzir
              </>
            )}
          </button>
        </section>

        {translatedText && (
          <section className="output-section">
            <h2>Tradução</h2>
            <div className="translated-text">
              {translatedText}
            </div>
            
            <div className="audio-controls">
              <div className="playback-buttons">
                {!isPlaying ? (
                  <button 
                    className="play-button"
                    onClick={handlePlayAudio}
                    aria-label="Ouvir tradução"
                  >
                    {icons.play} Ouvir
                  </button>
                ) : (
                  <button 
                    className="pause-button"
                    onClick={handlePauseAudio}
                    aria-label="Pausar reprodução"
                  >
                    {icons.pause} Pausar
                    <div className="sound-wave">
                      <span></span>
                      <span></span>
                      <span></span>
                      <span></span>
                      <span></span>
                    </div>
                  </button>
                )}
              </div>
              
              <div className="voice-controls">
                <label htmlFor="voice-type">Voz:</label>
                <select 
                  id="voice-type" 
                  value={voiceType}
                  onChange={(e) => setVoiceType(e.target.value)}
                >
                  <option value="default">Padrão</option>
                  <option value="male">Masculina</option>
                  <option value="female">Feminina</option>
                </select>
                
                <label htmlFor="speech-rate">Velocidade:</label>
                <input 
                  type="range" 
                  id="speech-rate" 
                  min="0.5" 
                  max="2" 
                  step="0.1" 
                  value={speechRate}
                  onChange={(e) => setSpeechRate(parseFloat(e.target.value))}
                />
              </div>
            </div>
          </section>
        )}
      </main>

      <footer className="app-footer">
        <button 
          className="theme-toggle" 
          onClick={toggleTheme}
          aria-label="Alternar tema"
        >
          {isDarkTheme ? (
            <>
              {icons.sun} Modo Claro
            </>
          ) : (
            <>
              {icons.moon} Modo Escuro
            </>
          )}
        </button>
        <p>VozMundo &copy; 2025</p>
      </footer>
    </div>
  )
}

export default App
